export { default as getEnvVariable } from './getEnvVariable';
